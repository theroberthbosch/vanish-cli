# Vanish Protocol v2.1

**Author**: Mr. B 
**Tool Name**: `vanish-cli` 
**Category**: Wireless Hacking / Handshake Capture 
**Platform**: Kali Linux / Parrot OS

---

## Features

- Stealthy WPA handshake capture
- Deauth attack with `mdk4`
- Live capture via `airodump-ng`
- Kill switch to instantly stop and clean
- Hidden vault storage: `~/.vault/handshakes`
- Automatic cracking with `rockyou.txt`
- Detects and installs missing wordlist
- Terminal detection for GNOME, XTerm, or Konsole
- Clean `.deb` installer and command-line tool

---

## Installation (from .deb)

```bash
sudo dpkg -i vanish-cli.deb
